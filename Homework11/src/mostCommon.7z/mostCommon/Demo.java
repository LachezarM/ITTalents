package mostCommon;

public class Demo {
	
	public static void main(String[] args) {
		 
		CommonLetters demo = new CommonLetters();
		Pair.userText = "His name is Slim Shady";
		
		demo.makeGraph();
		demo.printGraph();
	}
}
