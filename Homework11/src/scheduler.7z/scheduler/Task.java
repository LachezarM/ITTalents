package scheduler;

public interface Task {
	
	void doWork() throws InterruptedException;
}
